#export PATH=$PATH:./jre1.8.0_211/bin
export PATH=./jre1.8.0_211/bin
java -jar jar-copy-1.0.jar server